<?php $title = 'Xwegbe - Liste des appartements'; ?>

<?php ob_start(); ?>
<h1>Liste des appartements !</h1>

<?php
while ($appartement = $appartements->fetch())
{
   ?>
                <div class="appartements__content">
                        <div class="appartments__content__details">

                        <?php 
                            foreach ($appartements as $appartement):
                        ?>
                            <div class="item">
                            <img src="<?= $appartement->picture_1 ?>">
                                <h2 class="appartment_name">
                                    <?=$appartement->appartement_name ?>
                                </h2> <br>

                                <p class="daily_price">
                                    A partir de : <span> <?= $appartement->daily_price ?></span> FCFA HT
                                </p>

                                <p class="extract">
                                <?= $appartement->extract ?> 
                                </p> 

                                <p class="rooms">
                                    Nombre de chambres:  <span><?= $appartement->rooms ?></span>
                                </p>

                                <div class="buttons">
                                    <button class="book">
                                        <a href="booking.php?id=<?php echo $appartement->id; ?>">Réserver maintenant</a>
                                    </button>

                                    <button class="details">
                                        <a href="appartement.php?id=<?php echo $appartement->id;  ?>">Voir les détails</a>
                                    </button>
                                </div>
                            </div>

                        <?php  endforeach ?>
                </div>
    <?php
}

$appartements->closeCursor();
?>
<?php $content = ob_get_clean(); ?>

<?php require('template.php'); ?>
