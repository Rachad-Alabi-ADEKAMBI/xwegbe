<?php
try {
	/*base: adra7128_xwegbe
	passwd: 3o5D3WiKeU53
	user: adra7128_gilles
	host: localhost
	*/
	$bdd = new PDO('mysql:host=localhost;dbname=xwegbe;charset=utf8', 'root', '');
	$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}
/*
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ATTR_ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);*/