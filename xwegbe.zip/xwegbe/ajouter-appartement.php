<?php 
    require 'control.php'; 

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include 'meta.php'; ?>

    <title>Ajout appartement</title>
</head>
<body>
    <div cl<?php $title = 'Moifier commentaire'; ?>
<?php ob_start(); ?>
<h1>Modifier un commentaire</h1>

<form action="./index.php?action=editComment&amp;id=<?= $comment['id'] ?>" method="post">
    <div>
        <label for="comment">Nouveau commentaire</label><br />
        <textarea id="comment" name="comment"></textarea>
    </div>

    <div>
        <input type="submit" />
    </div>
</form>

?>
<?php $content = ob_get_clean(); ?>

<?php require('template.php'); ?>ass="container">
    <?php include 'header.php'; ?>

        <div class="add">
            <p class="add__back-link">
                <img src="" alt=""> <a href="admin.php">Retour au tableau de bord</a>
            </p>

            
        </div>
    </div>
    <?php include 'footer.php'; ?>
</body>
</html>

