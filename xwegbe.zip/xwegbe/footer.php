<footer class="footer">
            <div class="footer__top">

            </div>

            <div class="footer__bottom">
               <div class="footer__bottom__infos">
                   <div class="footer-logo">
                       <img src="public/images/logo.png" alt="">
                   </div>

                   <div class="footer-adress">
                       <img src="public/icons/map.svg" alt=""> 
                       <p>
                        Cotonou, adresse
                       </p>
                   </div>

                   <div class="footer-contact">
                    <img src="public/icons/map.svg" alt=""> 
                    <p>67 0000000</p>
                </div>
               </div>

                <div class="footer__bottom__menu">
                    <h3>
                        Liens rapides
                    </h3>

                    <ul>
                        <li>
                            <a href="index.php">Qui sommes nous ?</a>
                        </li>

                        <li>
                            <a href="index.php">Appartements</a>
                        </li>

                        

                        <li>
                            <a href="index.php">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <hr>

            <p class="footer__copyright">Xwegbe @ 2020 Tous droits réservés</p>
        </footer>