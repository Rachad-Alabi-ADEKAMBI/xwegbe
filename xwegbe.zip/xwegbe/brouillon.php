<?php session_start(); 

    require 'db.php';
    require 'control.php';

    $number_of_people = $_GET['number_of_people'];

    echo $number_of_people;

    $req = $bdd->prepare("SELECT * FROM appartements 
            WHERE appartment_status = 'libre'
            and rooms = ?
            ORDER BY rating");

    $req->execute(array(($number_of_people)));

    while ($datas = $req->fetch()){ ?>
     


<!DOCTYPE html>
<html lang="en">
<head>
    <?php include 'meta.php' ?>

    <title>Fineblock - Resultats de la recherche</title>
</head>
<body>
    <div class="container">
    <?php include 'header.php'; ?>
        <div class="appartments">
            <h1 class="appartments__title">
                Resultats de la recherche
            </h1>

            <div class="appartments__content">
                <div class="appartments__content__details">
                    <div class="item">
                            <img src="public/images/xwegbe.png">
                        <h2 class="appartment_name">
                            <?=$datas['appartement_name']?>
                        </h2> <br>

                        <p class="daily_price">
                            A partir de : <span> <?php echo $datas['daily_price'] ?></span> FCFA HT
                        </p>

                        <p class="extract">
                        <?php echo $datas['appartement_name'] ?> 
                        </p> 

                        <p class="rooms">
                            Nombre de chambres:  <span><?php echo $datas['rooms'] ?></span>
                        </p>

                        <div class="buttons">
                            <button class="book">
                                <a href="reserver.php?id=<?php $datas['id'] ?>">Réserver maintenant</a>
                            </button>

                            <button class="details">
                                <a href="appartement.php?id=<?php $datas['id'] ?>">Voir les détails</a>
                            </button>
                        </div>
                        <?php
    }
    ?>
                    </div>
                
                    
    </div>
                </div>
                <?php include 'footer.php'; ?>
</body>
</html>