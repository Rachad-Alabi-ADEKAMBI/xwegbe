<?php session_start(); 

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include 'meta.php'; ?>

    <title>Xwegbe - Accueil</title>
</head>
<body>
    
   <div class="container">
   <?php include 'header.php'; ?>

        <form action="" class="reservation">
            <h1 class="reservation__title">
                Détails de la réservation
            </h1>
        </form>
   </div>

    <?php include 'footer.php'; ?>
    <script src="public/js/script.js" ></script>
</body>
</html>