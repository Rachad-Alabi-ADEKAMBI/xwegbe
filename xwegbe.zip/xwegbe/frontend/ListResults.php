<?php $title = htmlspecialchars($post['title']); ?>

<?php ob_start(); ?>
<h1>Xwegbe - Resultats de la recherche</h1>

<p><a href="./index.php">Retour à l'accueil</a></p>

<div class="container">
    <?php include 'header.php'; ?>

        <div class="appartments">
            <h1 class="appartments__title">
                Resultats de la recherche
            </h1>
<?php
 while ($datas = $req->fetch())
    { ?>
        <div class="appartments__content">
            <div class="appartments__content__details">
                <div class="item">
                        <img src="public/images/xwegbe.png">
                    <h2 class="appartment_name">
                        <?=$datas['appartement_name']?>
                    </h2> <br>

                    <p class="daily_price">
                        A partir de : <span> <?php echo $datas['daily_price'] ?></span> FCFA HT
                    </p>

                    <p class="extract">
                    <?php echo $datas['appartement_name'] ?> 
                    </p> 

                    <p class="rooms">
                        Nombre de chambres:  <span><?php echo $datas['rooms'] ?></span>
                    </p>

                    <div class="buttons">
                        <button class="book">
                            <a href="reservation.php?id=<?php $datas['id'] ?>">Réserver maintenant</a>
                        </button>

                        <button class="details">
                            <a href="appartement.php?id=<?php $datas['id'] ?>">Voir les détails</a>
                        </button>
                    </div>
                    <?php
}
?>
<?php $content = ob_get_clean(); ?>

<?php require('template.php'); ?>
