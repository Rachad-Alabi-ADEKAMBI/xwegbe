<?php $title = 'Xwegbe - Editer le prixe'; ?>
<?php ob_start(); ?>
<h1>Modifier le prix d'un appartement</h1>

<form action="./index.php?action=editPrice&amp;daily_price=<?= $_GET['daily_price']?>&amp;=<?= $_GET['id']?>"> method='POST'>
   
        <label for="comment">Nouveau tarif journalier: <br>
            <input type="number">
        </label><br />

        <button type="submit">
            Modifier
        </button>
</form>

?>
<?php $content = ob_get_clean(); ?>

<?php require('template.php'); ?>