<?php $title = htmlspecialchars($post['title']); ?>

<?php ob_start(); ?>
<h1>Xwegbe - Voir appartement</h1>

<p><a href="./index.php">Retour à aux appartements</a></p>

<div class="news">
  
    
    <p>
        <?= nl2br(htmlspecialchars($appartement['content'])) ?>
    </p>
</div>

<?php
while ($appartement = $appartements->fetch())
{
?>
      <h1 class="appartment_name">
                        <?= $appartment['appartement_name'] ?> 
                    </h1>

                    <p class="appartment_extract">
                    <?= $appartment['extract'] ?> 
                    </p>

                    <p class="appartment_description">
                        <?= $appartment['appartement_description'] ?>
                    </p>

                    <button class="book">
                        <a href="reservation.php">
                            Reserver
                        </a>
                    </button>
<?php
}
?>
<?php $content = ob_get_clean(); ?>

<?php require('template.php'); ?>
